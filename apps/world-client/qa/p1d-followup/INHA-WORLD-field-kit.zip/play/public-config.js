export default {"siteOrigin":null,"syncOrigin":null,"firebase":null};
