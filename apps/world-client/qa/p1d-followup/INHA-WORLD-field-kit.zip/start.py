"""Run the local INHA WORLD build. Use --lan to play from a phone on the same Wi-Fi."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class LocalGame(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/health':
            data=b'{"local":true}'
            self.send_response(503)
            self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        else:
            super().do_GET()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lan',action='store_true')
    parser.add_argument('--port',type=int,default=8080)
    args=parser.parse_args()
    address='0.0.0.0' if args.lan else '127.0.0.1'
    files=partial(LocalGame,directory=str(Path(__file__).resolve().parent/'play'))
    with ThreadingHTTPServer((address,args.port),files) as server:
        print(f'INHA WORLD   http://127.0.0.1:{server.server_port}',flush=True)
        if args.lan:
            print('휴대폰에서 같은 Wi-Fi의 PC 로컬 IP와 위 포트로 접속하세요.',flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
