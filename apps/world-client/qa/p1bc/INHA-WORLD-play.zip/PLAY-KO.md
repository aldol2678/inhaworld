# INHA WORLD 로컬 플레이

ZIP을 푼 폴더에서 Python 3으로 `python3 start.py`를 실행하고, 브라우저에서 http://127.0.0.1:8080 을 연다. Windows에서는 `py start.py`를 사용할 수 있다. Node 설치와 별도 게임 서버 없이 `play/`의 같은 WebGL2 빌드가 PC와 모바일에서 동작한다.

휴대폰으로 플레이하려면 PC와 같은 Wi-Fi에 연결하고 PC에서 `python3 start.py --lan`을 실행한다. 휴대폰 브라우저에서 PC의 사설 IP와 포트 8080을 연다. 포트를 바꾸려면 `--port 8081`처럼 지정한다.

PC에서는 장면을 클릭해 마우스로 방향을 돌리고 WASD 또는 화살표로 이동한다. Esc로 포인터 잠금을 풀 수 있다. 휴대폰 가로 화면에서는 왼손 드래그가 이동, 오른손 드래그가 시점 회전이다. 상단 그래픽 메뉴의 수동 선택은 새로고침 뒤에도 같은 브라우저에 저장된다.

빌드는 로컬 게스트 모드로 시작한다. 퀘스트·닉네임·방명록은 브라우저의 해당 출처에 저장된다. PC와 휴대폰의 로컬 저장은 각각 독립적이다.

화면 비교와 QA는 아래 GitHub 브랜치에서 볼 수 있다.
https://github.com/aldol2678/inhaworld/tree/codex/world-map-p1bc-canal-quality/apps/world-client/qa/p1bc
